create table sala (
  id bigserial primary key,
  nome varchar(120) not null unique,
  capacidade int not null check (capacidade > 0),
  localizacao varchar(120) not null,
  ativa boolean not null default true
);

create table recurso (
  id bigserial primary key,
  nome varchar(120) not null unique,
  tipo varchar(60) not null,
  ativo boolean not null default true
);

create table reserva (
  id bigserial primary key,
  sala_id bigint not null references sala(id),
  inicio timestamp not null,
  fim timestamp not null,
  solicitante_email varchar(180) not null,
  titulo varchar(140) not null,
  observacao varchar(500)
);

create table reserva_recursos (
  reserva_id bigint not null references reserva(id) on delete cascade,
  recurso_id bigint not null references recurso(id),
  primary key (reserva_id, recurso_id)
);

insert into sala(nome, capacidade, localizacao) values
('Sala Azul', 8, '2º andar'),
('Sala Verde', 12, '3º andar');

insert into recurso(nome, tipo) values
('Projetor Epson', 'PROJETOR'),
('TV 65"', 'TV'),
('Kit Videoconferência', 'VCAM');
