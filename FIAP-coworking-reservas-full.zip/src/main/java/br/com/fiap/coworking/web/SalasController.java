package br.com.fiap.coworking.web;

import br.com.fiap.coworking.domain.Sala;
import br.com.fiap.coworking.repo.SalaRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller @RequiredArgsConstructor @RequestMapping("/salas")
public class SalasController {
  private final SalaRepository salaRepo;
  @GetMapping public String lista(Model model){ model.addAttribute("salas", salaRepo.findAll()); return "salas/lista"; }
  @GetMapping("/nova") public String nova(Model model){ model.addAttribute("sala", new Sala()); return "salas/form"; }
  @PostMapping public String criar(@Valid @ModelAttribute("sala") Sala sala, BindingResult br){ if (br.hasErrors()) return "salas/form"; salaRepo.save(sala); return "redirect:/salas"; }
  @GetMapping("/{id}/editar") public String editar(@PathVariable Long id, Model model){ model.addAttribute("sala", salaRepo.findById(id).orElseThrow()); return "salas/form"; }
  @PostMapping("/{id}") public String atualizar(@PathVariable Long id, @Valid @ModelAttribute("sala") Sala sala, BindingResult br){ if (br.hasErrors()) return "salas/form"; sala.setId(id); salaRepo.save(sala); return "redirect:/salas"; }
  @PostMapping("/{id}/excluir") public String excluir(@PathVariable Long id){ salaRepo.deleteById(id); return "redirect:/salas"; }
}
