package br.com.fiap.coworking.web;

import br.com.fiap.coworking.repo.ReservaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller @RequiredArgsConstructor
public class HomeController {
  private final ReservaRepository reservaRepo;
  @GetMapping("/") public String index(Model model) {
    model.addAttribute("reservas", reservaRepo.findAll());
    return "index";
  }
}
