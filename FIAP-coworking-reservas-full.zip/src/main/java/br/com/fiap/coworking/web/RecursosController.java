package br.com.fiap.coworking.web;

import br.com.fiap.coworking.domain.Recurso;
import br.com.fiap.coworking.repo.RecursoRepository;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller @RequiredArgsConstructor @RequestMapping("/recursos")
public class RecursosController {
  private final RecursoRepository recursoRepo;
  @GetMapping public String lista(Model model){ model.addAttribute("recursos", recursoRepo.findAll()); return "recursos/lista"; }
  @GetMapping("/novo") public String novo(Model model){ model.addAttribute("recurso", new Recurso()); return "recursos/form"; }
  @PostMapping public String criar(@Valid @ModelAttribute("recurso") Recurso recurso, BindingResult br){ if (br.hasErrors()) return "recursos/form"; recursoRepo.save(recurso); return "redirect:/recursos"; }
  @GetMapping("/{id}/editar") public String editar(@PathVariable Long id, Model model){ model.addAttribute("recurso", recursoRepo.findById(id).orElseThrow()); return "recursos/form"; }
  @PostMapping("/{id}") public String atualizar(@PathVariable Long id, @Valid @ModelAttribute("recurso") Recurso recurso, BindingResult br){ if (br.hasErrors()) return "recursos/form"; recurso.setId(id); recursoRepo.save(recurso); return "redirect:/recursos"; }
  @PostMapping("/{id}/excluir") public String excluir(@PathVariable Long id){ recursoRepo.deleteById(id); return "redirect:/recursos"; }
}
