package br.com.fiap.coworking.repo;

import br.com.fiap.coworking.domain.Sala;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SalaRepository extends JpaRepository<Sala, Long> {
  Optional<Sala> findByNome(String nome);
}
