package br.com.fiap.coworking.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Sala {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @NotBlank @Size(max=120) @Column(unique = true) private String nome;
  @NotNull @Min(1) private Integer capacidade;
  @NotBlank @Size(max=120) private String localizacao;
  @NotNull private Boolean ativa = true;
}
