package br.com.fiap.coworking.repo;

import br.com.fiap.coworking.domain.Recurso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecursoRepository extends JpaRepository<Recurso, Long> { }
