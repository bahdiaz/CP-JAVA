package br.com.fiap.coworking.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Recurso {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @NotBlank @Size(max=120) @Column(unique = true) private String nome;
  @NotBlank @Size(max=60) private String tipo;
  @NotNull private Boolean ativo = true;
}
