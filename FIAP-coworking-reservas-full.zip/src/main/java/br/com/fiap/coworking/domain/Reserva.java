package br.com.fiap.coworking.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;

@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Reserva {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false) private Sala sala;
  @NotNull private Instant inicio;
  @NotNull private Instant fim;
  @NotBlank @Size(max=180) private String solicitanteEmail;
  @NotBlank @Size(max=140) private String titulo;
  @Size(max=500) private String observacao;

  @ManyToMany
  @JoinTable(name="reserva_recursos",
    joinColumns=@JoinColumn(name="reserva_id"),
    inverseJoinColumns=@JoinColumn(name="recurso_id"))
  private Set<Recurso> recursos = new LinkedHashSet<>();
}
