package br.com.fiap.coworking.web;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class})
  public String handleBusiness(RuntimeException ex, Model model) {
    model.addAttribute("errorMessage", ex.getMessage());
    return "erro";
  }
}
