package br.com.fiap.coworking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoworkingReservasApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoworkingReservasApplication.class, args);
    }
}
