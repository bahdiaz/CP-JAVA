"package br.com.fiap.coworking.repo;

import br.com.fiap.coworking.domain.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.Instant;
import java.util.List;

public interface ReservaRepository extends JpaRepository<Reserva, Long> {
  @Query("""
    select r from Reserva r
    where r.sala.id = :salaId
      and r.fim   > :inicio
      and r.inicio < :fim
      and (:ignoreId is null or r.id <> :ignoreId)
  """)
  List<Reserva> conflitos(@Param("salaId") Long salaId,
                          @Param("inicio") Instant inicio,
                          @Param("fim") Instant fim,
                          @Param("ignoreId") Long ignoreId);
}
