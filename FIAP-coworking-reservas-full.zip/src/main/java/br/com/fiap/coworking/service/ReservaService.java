package br.com.fiap.coworking.service;

import br.com.fiap.coworking.domain.Recurso;
import br.com.fiap.coworking.domain.Reserva;
import br.com.fiap.coworking.repo.RecursoRepository;
import br.com.fiap.coworking.repo.ReservaRepository;
import br.com.fiap.coworking.repo.SalaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Duration;
import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service @RequiredArgsConstructor
public class ReservaService {
  private final ReservaRepository reservaRepo;
  private final SalaRepository salaRepo;
  private final RecursoRepository recursoRepo;

  @Transactional
  public Reserva criar(Reserva r, List<Long> recursosIds) {
    validarJanela(r.getInicio(), r.getFim());
    validarConflito(r.getSala().getId(), r.getInicio(), r.getFim(), null);
    Reserva salvo = reservaRepo.save(r);
    vincularRecursos(salvo, recursosIds);
    return salvo;
  }

  @Transactional
  public Reserva atualizar(Long id, Reserva r, List<Long> recursosIds) {
    Reserva atual = reservaRepo.findById(id).orElseThrow();
    validarJanela(r.getInicio(), r.getFim());
    validarConflito(r.getSala().getId(), r.getInicio(), r.getFim(), id);
    atual.setTitulo(r.getTitulo());
    atual.setObservacao(r.getObservacao());
    atual.setInicio(r.getInicio());
    atual.setFim(r.getFim());
    atual.setSala(salaRepo.findById(r.getSala().getId()).orElseThrow());
    vincularRecursos(atual, recursosIds);
    return atual;
  }

  private void validarJanela(Instant ini, Instant fim) {
    if (fim.isBefore(ini)) throw new IllegalArgumentException("Fim deve ser após o início");
    if (Duration.between(ini, fim).toHours() > 8) throw new IllegalArgumentException("Máx. 8h por reserva");
  }
  private void validarConflito(Long salaId, Instant ini, Instant fim, Long ignoreId) {
    if (!reservaRepo.conflitos(salaId, ini, fim, ignoreId).isEmpty())
      throw new IllegalStateException("Conflito de horário nesta sala");
  }
  private void vincularRecursos(Reserva r, List<Long> recursosIds) {
    Set<Recurso> recursos = new HashSet<>();
    if (recursosIds != null) {
      for (Long id : recursosIds) {
        Recurso rc = recursoRepo.findById(id).orElseThrow();
        if (Boolean.TRUE.equals(rc.getAtivo())) recursos.add(rc);
      }
    }
    r.setRecursos(recursos);
  }
}
