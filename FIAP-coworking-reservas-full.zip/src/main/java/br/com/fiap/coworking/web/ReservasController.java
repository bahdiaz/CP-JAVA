package br.com.fiap.coworking.web;

import br.com.fiap.coworking.domain.Reserva;
import br.com.fiap.coworking.repo.RecursoRepository;
import br.com.fiap.coworking.repo.ReservaRepository;
import br.com.fiap.coworking.repo.SalaRepository;
import br.com.fiap.coworking.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@Controller @RequiredArgsConstructor @RequestMapping("/reservas")
public class ReservasController {
  private final ReservaRepository reservaRepo;
  private final SalaRepository salaRepo;
  private final RecursoRepository recursoRepo;
  private final ReservaService reservaService;

  @GetMapping public String lista(Model model){ model.addAttribute("reservas", reservaRepo.findAll()); return "reservas/lista"; }

  @GetMapping("/nova")
  public String nova(Model model, @AuthenticationPrincipal OAuth2User user) {
    Reserva r = new Reserva();
    if (user != null) r.setSolicitanteEmail(user.getAttribute("email"));
    model.addAttribute("reserva", r);
    model.addAttribute("salas", salaRepo.findAll());
    model.addAttribute("recursos", recursoRepo.findAll());
    return "reservas/form";
  }

  @PostMapping
  public String criar(@Valid @ModelAttribute("reserva") Reserva reserva,
                      BindingResult br,
                      @RequestParam(value="recursosSelecionados", required=false) List<Long> recursosSelecionados,
                      @RequestParam("inicioLocal") String inicioLocal,
                      @RequestParam("fimLocal") String fimLocal) {
    if (br.hasErrors()) return "reservas/form";
    reserva.setInicio(parseLocal(inicioLocal));
    reserva.setFim(parseLocal(fimLocal));
    reservaService.criar(reserva, recursosSelecionados);
    return "redirect:/reservas";
  }

  @GetMapping("/{id}/editar")
  public String editar(@PathVariable Long id, Model model) {
    var r = reservaRepo.findById(id).orElseThrow();
    model.addAttribute("reserva", r);
    model.addAttribute("salas", salaRepo.findAll());
    model.addAttribute("recursos", recursoRepo.findAll());
    return "reservas/form";
  }

  @PostMapping("/{id}")
  public String atualizar(@PathVariable Long id,
                          @Valid @ModelAttribute("reserva") Reserva reserva,
                          BindingResult br,
                          @RequestParam(value="recursosSelecionados", required=false) List<Long> recursosSelecionados,
                          @RequestParam("inicioLocal") String inicioLocal,
                          @RequestParam("fimLocal") String fimLocal) {
    if (br.hasErrors()) return "reservas/form";
    reserva.setInicio(parseLocal(inicioLocal));
    reserva.setFim(parseLocal(fimLocal));
    reservaService.atualizar(id, reserva, recursosSelecionados);
    return "redirect:/reservas";
  }

  @PostMapping("/{id}/excluir")
  public String excluir(@PathVariable Long id) {
    reservaRepo.deleteById(id);
    return "redirect:/reservas";
  }

  private Instant parseLocal(String s) {
    var ldt = LocalDateTime.parse(s);
    return ldt.atZone(ZoneId.systemDefault()).toInstant();
  }
}
